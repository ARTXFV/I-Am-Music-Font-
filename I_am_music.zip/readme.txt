License: Free for commercia use

Font who mix the "serif" and "sans-serif" style.
Font inspired by Playboi Carti's album "MUSIC".

